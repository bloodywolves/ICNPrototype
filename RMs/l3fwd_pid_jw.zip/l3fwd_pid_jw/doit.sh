sudo ./build/l3fwd -c 0x78 -n 1 -- -p 0xF --config="(0,0,3),(1,0,4),(2,0,5),(3,0,6)"
#sudo ./build/l3fwd -c 0x1F -n 1 -- -p 0x1F --config="(0,0,0),(1,0,1),(2,0,2),(3,0,3),(4,0,4)"
