#ifndef _WENXINGBENG_H_
#define _WENXINGBENG_

#include "CoLoR.h"

#endif /* _WENXINGBENG_H_ */
